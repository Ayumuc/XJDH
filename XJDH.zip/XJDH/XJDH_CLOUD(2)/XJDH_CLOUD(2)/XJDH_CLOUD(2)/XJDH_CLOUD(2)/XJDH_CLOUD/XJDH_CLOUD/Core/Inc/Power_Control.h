/*
 * Power_Control.h
 *
 *  Created on: Jun 18, 2024
 *      Author: Administrator
 */

#ifndef SRC_POWER_CONTROL_H_
#define SRC_POWER_CONTROL_H_

uint8_t Power_Contorl_BLUE(void);
uint8_t Power_Contorl_AD(void);
uint8_t Power_Contorl_NET(void);



#endif /* SRC_POWER_CONTROL_H_ */
